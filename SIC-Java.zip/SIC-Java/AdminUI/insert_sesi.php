<?php
include "../Connection.php";

$tingkat = $_POST['tingkat-dropdown'];
$jurusan = $_POST['jurusan-dropdown'];
$kelas = $_POST['kelas-dropdown'];
$mapel = $_POST['mapel-dropdown'];
$semester = $_POST['semester-dropdown'];
$tahun = $_POST['tahun'];
$guru = $_POST['guru-dropdown'];
$lantai = $_POST['lantai-dropdown'];
$ruangan = $_POST['ruangan-dropdown'];
$nama = $_POST['namaSesi'];
$sesi = $_POST['sesi'];
$tanggal = $_POST['tanggal'];
$mulai = $_POST['mulai'];
$selesai = $_POST['selesai'];

$queryKelas = mysqli_query($koneksi, "SELECT IDKelas FROM kelas WHERE Tingkat='$tingkat' AND Jurusan='$jurusan' AND KodeKelas='$kelas'") or die(mysqli_error());

while ($data = mysqli_fetch_array($queryKelas)) { //Hasil output querynya masih berupa object, jadi harus difetch
    $idKelas = ($data['IDKelas']);
}

$query = mysqli_query($koneksi, "INSERT INTO sesimapel (IDSesi, IDMapel, IDKelas, Semester, Tahun, IDGuru, IDRuangan, NamaSesi, Tanggal, JamMulai, JamBerakhir)
VALUES ('$sesi', '$mapel', '$idKelas', '$semester', '$tahun', '$guru', '$ruangan', '$nama', '$tanggal', '$mulai', '$selesai')") or die(mysqli_error());

if ($query) {
    ?>
    <script language="JavaScript">
        document.location = 'tambah_sesi.php'</script>
<?php
}
?>