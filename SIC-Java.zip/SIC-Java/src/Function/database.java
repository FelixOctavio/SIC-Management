package Function;

import java.sql.*;

public class database {
    private String q;
    
    public database(String q){
        this.q = q;
    }
    
    public ResultSet getResult(){
        ResultSet result = null;
        try{
            Connection con = (Connection) connectDatabase.getCon();
            Statement st = con.createStatement();
            result = st.executeQuery(q);
        }
        catch(SQLException e){
            System.out.println("Connection Failed");
        }
        return result;
    }
}
