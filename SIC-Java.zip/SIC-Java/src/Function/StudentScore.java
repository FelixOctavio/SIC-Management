package Function;

import java.util.ArrayList;

public class StudentScore {
    private int idSiswa;
    private int kodeKelas;
    private String nama;
    private ArrayList<ScoreMapel> sm = new ArrayList<>();
    public StudentScore(int idSiswa, int kodeKelas, String nama){
        this.idSiswa = idSiswa;
        this.kodeKelas = kodeKelas;
        this.nama = nama;
    }
    public void addMapel(int idMapel){
        sm.add(new ScoreMapel(idMapel));
    }
    public void addUts(int idMapel, double score){
        for(int i = 0; i < sm.size(); i++){
            if(sm.get(i).getIdMapel() == idMapel){
                sm.get(i).addUts(score);
            }
        }
    }
    public void addUas(int idMapel, double score){
        for(int i = 0; i < sm.size(); i++){
            if(sm.get(i).getIdMapel() == idMapel){
                sm.get(i).addUas(score);
            }
        }
    }
    public void addUlangan(int idMapel, double score){
        for(int i = 0; i < sm.size(); i++){
            if(sm.get(i).getIdMapel() == idMapel){
                sm.get(i).addUlangan(score);
            }
        }
    }
    public void addTugas(int idMapel, double score){
        for(int i = 0; i < sm.size(); i++){
            if(sm.get(i).getIdMapel() == idMapel){
                sm.get(i).addTugas(score);
            }
        }
    }
    public double getFinalScore(){
        double temp = 0;
        for(int i = 0; i < sm.size(); i++){
            double t = sm.get(i).getAVG() / sm.size();
            temp = temp + t;
        }
        return temp;
    }
    public int getIdSiswa(){
        return this.idSiswa;
    }
    public int getKodeKelas(){
        return this.kodeKelas;
    }
    public String getNama(){
        return this.nama;
    }
}
