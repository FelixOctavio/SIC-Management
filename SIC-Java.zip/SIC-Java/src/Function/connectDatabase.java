package Function;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class connectDatabase {
    private static Connection db;
    
    public static Connection getCon() throws SQLException{
        try{
            String DB = "jdbc:mysql://localhost:3306/sic?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String user = "root";
            String pw = "";  
            Connection temp = DriverManager.getConnection(DB, user, pw);
            if(temp != null){
                db = temp;
            }
        }
        catch (SQLException e){
            System.out.println("Failed to connect to database");
        }
        return db;
    }
}
