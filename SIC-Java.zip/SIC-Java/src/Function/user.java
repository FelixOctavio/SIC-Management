package Function;

public class user {
    private int userID;
    private String password;
    private String role;
    
    public user(int userID, String password, String role){
        this.userID = userID;
        this.password = password;
        this.role = role;
    }
    
    public int getID(){
        return this.userID;
    }
    
    public String getPw(){
        return this.password;
    }
    
    public String getRole(){
        return this.role;
    }
}
