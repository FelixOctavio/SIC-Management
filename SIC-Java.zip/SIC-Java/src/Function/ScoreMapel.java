package Function;

import java.util.ArrayList;

public class ScoreMapel {
    private int idMapel;
    private double uts;
    private double uas;
    private ArrayList<Double> ulangan = new ArrayList<>();
    private ArrayList<Double> tugas = new ArrayList<>();
    public ScoreMapel(int idMapel){
        this.idMapel = idMapel;
    }
    public void addUts(double score){
        this.uts = score;
    }
    public void addUas(double score){
        this.uas = score;
    }
    public void addUlangan(double score){
        this.ulangan.add(score);
    }
    public void addTugas(double score){
        this.tugas.add(score);
    }
    public int getIdMapel(){
        return this.idMapel;
    }
    public double getAVG(){
        double s1 = 0, s2 = 0;
        for(int i = 0; i < ulangan.size(); i++){
            double t = ulangan.get(i) / ulangan.size();
            s1 = s1 + t;
        }
        for(int i  = 0; i < tugas.size(); i++){
            double t = tugas.get(i) / tugas.size();
            s2 = s2 + t;
        }
        double final_score = (s1 + s2 + this.uts + this.uas)/4;
        return final_score; 
    }
}
