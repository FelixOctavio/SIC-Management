package main;

import GUI.Login;

public class main {
    public static void main (String[] args){
        new Login().setVisible(true);
    }
}
