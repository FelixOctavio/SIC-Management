<?php 
    include "../Connection.php"; 
    $poin = $_POST["Poin"];
?>
    <input type="number" name="Poin" size="30" value="<?php echo '99';?>">